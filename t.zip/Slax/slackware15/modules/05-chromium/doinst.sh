#!/bin/bash

UNION=$1
SLACKWARE=$2

rm -Rf $UNION/usr/share/applications/chromium.desktop
