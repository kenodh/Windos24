#!/bin/sh
# $1 = union directory
chown -R guest.users $1/home/guest
